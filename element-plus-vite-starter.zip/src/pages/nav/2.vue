<template>
  <div>
    Navigation 2
  </div>
</template>
